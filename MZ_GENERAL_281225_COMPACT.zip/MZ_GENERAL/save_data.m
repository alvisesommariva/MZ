
function save_data(domain,pset_type,A_mat,B_mat,cond_mat)

LR=num2str(size(A_mat,1));
LC=num2str(size(A_mat,2));


foldername='TABLES';

if ~exist(foldername,'dir')
    mkdir(foldername);
end

filenameA=['table_',domain,'_A_',num2str(pset_type),'_',LR,'_',LC,'.m'];
fidA=fopen(filenameA,'w+');
filenameB=['table_',domain,'_B_',num2str(pset_type),'_',LR,'_',LC,'.m'];
fidB=fopen(filenameB,'w+');
filenameC=['table_',domain,'_cond_',num2str(pset_type),'_',LR,'_',LC,'.m'];
fidC=fopen(filenameC,'w+');

str=['function A=',filenameA];
fprintf(fidA,str);
fprintf(fidA,'\n \n A=[ \n');
fprintf(fidA,[repmat('%f\t', 1, size(A_mat, 2)) '\n'], A_mat');
fprintf(fidA,'\n ]; \n');

fprintf(fidB,['function B=',filenameB]);
fprintf(fidB,'\n \n B=[ \n');
fprintf(fidB,[repmat('%f\t', 1, size(B_mat, 2)) '\n'], B_mat');
fprintf(fidB,'\n ]; \n');

fprintf(fidC,['function C=',filenameC]);
fprintf(fidC,'\n \n C=[ \n');
fprintf(fidC,[repmat('%f\t', 1, size(cond_mat, 2)) '\n'], cond_mat');
fprintf(fidC,'\n ]; \n');

fclose('all');

movefile(filenameA,foldername,'f');
movefile(filenameB,foldername,'f');
movefile(filenameC,foldername,'f');

