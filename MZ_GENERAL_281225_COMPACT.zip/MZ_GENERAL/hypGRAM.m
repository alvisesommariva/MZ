
function [coeff,G]=hypGRAM(V,fX,w,G)

%--------------------------------------------------------------------------
% Input
%--------------------------------------------------------------------------
% V: (quadrature) Vandermonde matrix at cubature nodes "X"
%    dim(V)=dim(polynomial space) x cardinality X
%    In other words it is the transpose of the interpolation Vandermonde
%    matrix.
%
% fX: evaluation of the function at the cubature nodes "X" (column vector)
%
% w : cubature weights (w.r.t. X)m (column vector)
%
% G: GRAM matrix
%--------------------------------------------------------------------------
% Output
%--------------------------------------------------------------------------
% coeff: Least-square coeff. w.r.t. the orthonormal basis that defines V.
%
% G: GRAM matrix (based on the rule with nodes "X" and weights "w"
%--------------------------------------------------------------------------
% Reference paper:
%--------------------------------------------------------------------------
% "On the role of weak Marcinkiewicz-Zygmund constants in polynomial 
% approximation by orthogonal bases"
% C. An, A. Sommariva and M. Vianello
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello <marcov@math.unipd.it>
%
% Date: December 27, 2025
%--------------------------------------------------------------------------

if nargin < 4
      G=compute_GRAM(V,w);
end

b=V*(w.*fX);

coeff=G\b;