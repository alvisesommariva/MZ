
function print_MZ_anomalies(mV,nV,table_data,A_mat,B_mat,MZ_mat)

for i=1:length(mV)
    m=mV(i);
    n1=table_data(i,4);

    if n1 > floor(m/2)

        fprintf('\n \n \t ............. degree anomalies ...............');
        fprintf('\n \n');

        n1L = floor(m/2)+1;
        i_n1L=find(nV == n1L);
        eta_valL=MZ_mat(i,i_n1L);
        cond2G_min=B_mat(i,i_n1L)/A_mat(i,i_n1L);

        n1H = n1;
        i_n1H=find(nV == n1H);
        eta_valH=MZ_mat(i,i_n1H);
        cond2G_max=B_mat(i,i_n1H)/A_mat(i,i_n1H);

        minval=0.9998;

        if eta_valH <= minval
            fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & %-1.3e & %-1.3e & %-1.3e & %-1.3e &&',...
                m,n1L,n1H,eta_valL,eta_valH,cond2G_min,cond2G_max);
        else
            if eta_valL >= minval
                fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & 1-%-1.3e & 1-%-1.3e  & %-1.3e & %-1.3e &&',...
                    m,n1L,n1H,1-eta_valL,1-eta_valH,cond2G_min,cond2G_max);
            else
                fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & %-1.3e & 1-%-1.3e  & %-1.3e & %-1.3e &&',...
                    m,n1L,n1H,eta_valL,1-eta_valH,cond2G_min,cond2G_max);
            end
        end
    end
end
