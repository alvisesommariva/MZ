
function table2figures

example=2;
switch example
    case 1
        table=table_square_QMC; domain='square'; pset_type=5;
    case 2
        table=table_cube_QMC; domain='cube'; pset_type=4;
end

save_fig=1;

mV=1:20;
nV=0:20;

% data from table as vectors
eta_vett=table(:,3);
A_vett=table(:,4);
B_vett=table(:,5);
cond_vett=table(:,6);

% rewrite as matrices
eta_mat=reshape(eta_vett,length(nV),length(mV));
A_mat=reshape(A_vett,length(nV),length(mV));
B_mat=reshape(B_vett,length(nV),length(mV));
cond_mat=reshape(cond_vett,length(nV),length(mV));


clf;
plot_MZ_figures(mV,nV,eta_mat',A_mat,B_mat,cond_mat',domain,...
    pset_type,save_fig)
