
function print_cond_anomalies(mV_mat,nV_mat,MZ_mat,cond_mat)

tol=10^6;

anomalies=0;

for i=1:size(mV_mat,1)
    for j=1:size(mV_mat,2)
        m=mV_mat(i,j); n=nV_mat(i,j); eta=MZ_mat(i,j); condL=cond_mat(i,j);

        if eta >= 1 && condL <= tol

            if anomalies == 0
                fprintf('\n \n \t  ............ cond anomalies ..........')
                fprintf('\n \n \t  m &  n &    eta    &    cond   &&')
                fprintf('\n');
                anomalies=1;
                fprintf('\n \t %2.0f & %2.0f & %1.3e & %1.3e &&',...
                    m,n,eta,condL);
            end
        end
    end
end

if anomalies == 1
    fprintf('\n \n');
end