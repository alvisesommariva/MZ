
function assembly_latex_table(table_data,mV)

L=length(table_data);

switch L
    case 1
        table_data_1=table_data{1};
        for k=1:length(mV)
            table_data_1L=table_data_1(k,:);
            fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f  &&',...
                table_data_1L(1),...
                table_data_1L(2),table_data_1L(3),table_data_1L(4),table_data_1L(5))
        end
    case 2
        table_data_1=table_data{1};
        table_data_2=table_data{2};
        for k=1:length(mV)
            table_data_1L=table_data_1(k,:);
            table_data_2L=table_data_2(k,:);
            fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f &&',...
                table_data_1L(1),...
                table_data_1L(2),table_data_1L(3),table_data_1L(4),table_data_1L(5),...
                table_data_2L(2),table_data_2L(3),table_data_2L(4),table_data_2L(5))
        end


    case 3
        table_data_1=table_data{1};
        table_data_2=table_data{2};
        table_data_3=table_data{3};
        for k=1:length(mV)
            table_data_1L=table_data_1(k,:);
            table_data_2L=table_data_2(k,:);
            table_data_3L=table_data_3(k,:);
            fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f &&',...
                table_data_1L(1),...
                table_data_1L(2),table_data_1L(3),table_data_1L(4),table_data_1L(5),...
                table_data_2L(2),table_data_2L(3),table_data_2L(4),table_data_2L(5),...
                table_data_3L(2),table_data_3L(3),table_data_3L(4),table_data_3L(5))
        end

    case 4
        table_data_1=table_data{1};
        table_data_2=table_data{2};
        table_data_3=table_data{3};
        table_data_4=table_data{4};
        for k=1:length(mV)
            table_data_1L=table_data_1(k,:);
            table_data_2L=table_data_2(k,:);
            table_data_3L=table_data_3(k,:);
            table_data_4L=table_data_4(k,:);
            fprintf('\n \t %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f & %-2.0f &&',...
                table_data_1L(1),...
                table_data_1L(2),table_data_1L(3),table_data_1L(4),table_data_1L(5),...
                table_data_2L(2),table_data_2L(3),table_data_2L(4),table_data_2L(5),...
                table_data_3L(2),table_data_3L(3),table_data_3L(4),table_data_3L(5),...
                table_data_4L(2),table_data_4L(3),table_data_4L(4),table_data_4L(5))
        end


end







fprintf('\n \n');
